<?php
// Installation and Setup Script for Shopify Order Tagging App
require_once 'config.php';

echo "<h1>Shopify Order Tagging App - Installation</h1>";

// Check if directories exist, create if not
$directories = ['logs', 'data', 'webhook'];
foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        if (mkdir($dir, 0755, true)) {
            echo "<p>✅ Created directory: $dir</p>";
        } else {
            echo "<p>❌ Failed to create directory: $dir</p>";
        }
    } else {
        echo "<p>✅ Directory exists: $dir</p>";
    }
}

// Test Shopify API connection
echo "<h2>Testing Shopify API Connection</h2>";
$url = "https://" . SHOPIFY_SHOP . "/admin/api/" . SHOPIFY_API_VERSION . "/shop.json";
$headers = [
    "Content-Type: application/json",
    "X-Shopify-Access-Token: " . SHOPIFY_ACCESS_TOKEN
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $shopData = json_decode($response, true);
    echo "<p>✅ API Connection successful!</p>";
    echo "<p>Shop: " . $shopData['shop']['name'] . "</p>";
    echo "<p>Domain: " . $shopData['shop']['domain'] . "</p>";
} else {
    echo "<p>❌ API Connection failed. HTTP Code: $httpCode</p>";
    echo "<p>Response: $response</p>";
}

// Initialize default rules
echo "<h2>Setting up default rules</h2>";
if (!file_exists(RULES_FILE)) {
    global $default_rules;
    if (file_put_contents(RULES_FILE, json_encode($default_rules, JSON_PRETTY_PRINT))) {
        echo "<p>✅ Default rules created successfully</p>";
    } else {
        echo "<p>❌ Failed to create default rules</p>";
    }
} else {
    echo "<p>✅ Rules file already exists</p>";
}

// Check file permissions
echo "<h2>File Permissions Check</h2>";
$checkFiles = [RULES_FILE, LOG_FILE];
foreach ($checkFiles as $file) {
    if (is_writable(dirname($file))) {
        echo "<p>✅ " . dirname($file) . " is writable</p>";
    } else {
        echo "<p>❌ " . dirname($file) . " is not writable</p>";
    }
}

echo "<h2>Setup Complete!</h2>";
echo "<p>Your webhook URL is: <strong>http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . "/webhook/order-tagging.php</strong></p>";
echo "<p><a href='index.php'>Go to Admin Interface</a></p>";

// Instructions
echo "<h2>Next Steps:</h2>";
echo "<ol>";
echo "<li>Copy the webhook URL above</li>";
echo "<li>Go to your Shopify admin: Settings → Notifications</li>";
echo "<li>Scroll down to 'Webhooks' section</li>";
echo "<li>Click 'Create webhook'</li>";
echo "<li>Set Event to 'Order creation'</li>";
echo "<li>Set Format to 'JSON'</li>";
echo "<li>Paste the webhook URL</li>";
echo "<li>Save the webhook</li>";
echo "<li>Test by creating a test order in your store</li>";
echo "</ol>";
?>