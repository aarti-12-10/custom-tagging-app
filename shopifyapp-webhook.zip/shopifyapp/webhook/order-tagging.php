<?php
// Enhanced Order Tagging Webhook
require_once '../config.php';  // if files are one directory up
require_once '../functions.php';

// Get order webhook payload
$data = file_get_contents("php://input");
$order = json_decode($data, true);

// Log incoming webhook for debugging
logMessage("Webhook received for order ID: " . $order['id']);

if (!$order || !isset($order['id'])) {
    logMessage("Invalid order data received");
    http_response_code(400);
    exit;
}

$order_id = $order['id'];
$total_price = floatval($order['total_price']);

// Get tagging rules from database/config
$rules = getTaggingRules();

$tags_to_apply = [];
$shipping_method = "Normal";

// Apply rules based on order total
foreach ($rules as $rule) {
    if (evaluateRule($rule, $total_price)) {
        if (!empty($rule['tag'])) {
            $tags_to_apply[] = $rule['tag'];
        }
        $shipping_method = $rule['shipping'];
        break; // Apply first matching rule
    }
}

// Apply tags if any
if (!empty($tags_to_apply)) {
    $success = applyTagsToOrder($order_id, implode(', ', $tags_to_apply));
    
    if ($success) {
        logMessage("Successfully tagged order $order_id with: " . implode(', ', $tags_to_apply));
        
        // Update shipping method (this would require additional API calls)
        updateOrderNotes($order_id, "Shipping method: $shipping_method");
        
    } else {
        logMessage("Failed to tag order $order_id");
    }
} else {
    logMessage("No tags applied to order $order_id (total: $total_price)");
}

http_response_code(200);
echo "OK";
?>