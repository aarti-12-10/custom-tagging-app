<?php
function logMessage($message) {
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp] $message" . PHP_EOL;
    file_put_contents(LOG_FILE, $logEntry, FILE_APPEND | LOCK_EX);
}

function getTaggingRules() {
    // Example rules - replace with your actual logic
    return [
        ['min_amount' => 100, 'tag' => 'VIP', 'shipping' => 'Express'],
        ['min_amount' => 50, 'tag' => 'Premium', 'shipping' => 'Fast'],
        ['min_amount' => 0, 'tag' => 'Standard', 'shipping' => 'Normal']
    ];
}

function evaluateRule($rule, $total_price) {
    return $total_price >= $rule['min_amount'];
}

function applyTagsToOrder($order_id, $tags) {
    $url = "https://" . SHOPIFY_SHOP_DOMAIN . "/admin/api/2023-10/orders/$order_id.json";
    
    $data = json_encode([
        'order' => [
            'id' => $order_id,
            'tags' => $tags
        ]
    ]);
    
    $headers = [
        'Content-Type: application/json',
        'X-Shopify-Access-Token: ' . SHOPIFY_ACCESS_TOKEN
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return $httpCode === 200;
}

function updateOrderNotes($order_id, $note) {
    $url = "https://" . SHOPIFY_SHOP_DOMAIN . "/admin/api/2023-10/orders/$order_id.json";
    
    $data = json_encode([
        'order' => [
            'id' => $order_id,
            'note' => $note
        ]
    ]);
    
    $headers = [
        'Content-Type: application/json',
        'X-Shopify-Access-Token: ' . SHOPIFY_ACCESS_TOKEN
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return $httpCode === 200;
}
?>