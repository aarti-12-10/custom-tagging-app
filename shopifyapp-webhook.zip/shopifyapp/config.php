<?php
// Shopify API Configuration
define('SHOPIFY_SHOP_DOMAIN', 'aarti1210.myshopify.com');
define('SHOPIFY_API_KEY', 'af038cce925bdf6dd066b01574360857');
define('SHOPIFY_API_SECRET', 'e65f47391756a7054e3dcca9aaed8b7f');
define('SHOPIFY_ACCESS_TOKEN', 'shpua_1860af592f6346e7b99577f76f7d472a');

// Database configuration (if using database)
define('DB_HOST', 'localhost');
define('DB_NAME', 'shopify_app');
define('DB_USER', 'root');
define('DB_PASS', '');

// Other settings
define('LOG_FILE', 'order_tagging.log');
?>
<?php
// Shopify App Configuration

// Shopify Store Details
define('SHOPIFY_SHOP', 'aarti1210.myshopify.com');
define('SHOPIFY_ACCESS_TOKEN', 'shpua_1860af592f6346e7b99577f76f7d472a');
define('SHOPIFY_API_VERSION', '2024-10');

// Database Configuration (if you want to store rules in database)
define('DB_HOST', 'localhost');
define('DB_NAME', 'shopify_app');
define('DB_USER', 'root');
define('DB_PASS', '');

// Default Tagging Rules
$default_rules = [
    [
        'id' => 1,
        'condition' => 'less_than',
        'value' => 100,
        'tag' => '',
        'shipping' => 'Normal',
        'active' => true
    ],
    [
        'id' => 2,
        'condition' => 'greater_than',
        'value' => 100,
        'tag' => 'High Value',
        'shipping' => 'Express',
        'active' => true
    ],
    [
        'id' => 3,
        'condition' => 'greater_than',
        'value' => 500,
        'tag' => 'Very High Value',
        'shipping' => 'Super Express',
        'active' => true
    ]
];

// App Settings
define('LOG_FILE', 'logs/app.log');
define('RULES_FILE', 'data/rules.json');

// Create necessary directories
if (!file_exists('logs')) {
    mkdir('logs', 0755, true);
}
if (!file_exists('data')) {
    mkdir('data', 0755, true);
}

// Initialize rules file if it doesn't exist
if (!file_exists(RULES_FILE)) {
    file_put_contents(RULES_FILE, json_encode($default_rules, JSON_PRETTY_PRINT));
}
?>