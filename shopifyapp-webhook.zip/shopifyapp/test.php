<?php
// Test Script for Shopify Order Tagging App
require_once 'config.php';
require_once 'functions.php';

echo "<h1>Shopify Order Tagging App - Test Suite</h1>";

// Test 1: Rules functionality
echo "<h2>Test 1: Rules Loading and Evaluation</h2>";
$rules = getTaggingRules();
echo "<p>Loaded " . count($rules) . " rules:</p>";
foreach ($rules as $rule) {
    echo "<p>- " . $rule['condition'] . " $" . $rule['value'] . " → Tag: '" . $rule['tag'] . "', Shipping: " . $rule['shipping'] . "</p>";
}

// Test 2: Rule evaluation with sample values
echo "<h2>Test 2: Rule Evaluation with Sample Order Values</h2>";
$testValues = [50, 150, 600, 1000];

foreach ($testValues as $value) {
    echo "<h3>Order Total: $value</h3>";
    $matchedRule = null;
    foreach ($rules as $rule) {
        if (evaluateRule($rule, $value)) {
            $matchedRule = $rule;
            break;
        }
    }
    
    if ($matchedRule) {
        echo "<p>✅ Matched Rule: " . $matchedRule['condition'] . " $" . $matchedRule['value'] . "</p>";
        echo "<p>Tag: '" . $matchedRule['tag'] . "', Shipping: " . $matchedRule['shipping'] . "</p>";
    } else {
        echo "<p>❌ No rules matched</p>";
    }
}

// Test 3: Webhook simulation
echo "<h2>Test 3: Webhook Simulation</h2>";
$sampleOrder = [
    'id' => 999999999,
    'total_price' => '250.00',
    'created_at' => date('c'),
    'name' => '#TEST001'
];

echo "<p>Simulating webhook with order:</p>";
echo "<pre>" . json_encode($sampleOrder, JSON_PRETTY_PRINT) . "</pre>";

$orderId = $sampleOrder['id'];
$totalPrice = floatval($sampleOrder['total_price']);

$tagsToApply = [];
$shippingMethod = "Normal";

foreach ($rules as $rule) {
    if (evaluateRule($rule, $totalPrice)) {
        if (!empty($rule['tag'])) {
            $tagsToApply[] = $rule['tag'];
        }
        $shippingMethod = $rule['shipping'];
        echo "<p>✅ Rule matched: " . json_encode($rule) . "</p>";
        break;
    }
}

if (!empty($tagsToApply)) {
    echo "<p>Would apply tags: " . implode(', ', $tagsToApply) . "</p>";
    echo "<p>Would set shipping: $shippingMethod</p>";
} else {
    echo "<p>No tags would be applied</p>";
}

// Test 4: API Connection
echo "<h2>Test 4: Shopify API Connection</h2>";
$url = "https://" . SHOPIFY_SHOP . "/admin/api/" . SHOPIFY_API_VERSION . "/orders.json?limit=1";
$headers = [
    "Content-Type: application/json",
    "X-Shopify-Access-Token: " . SHOPIFY_ACCESS_TOKEN
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $data = json_decode($response, true);
    echo "<p>✅ API Connection successful!</p>";
    echo "<p>Retrieved " . count($data['orders']) . " orders</p>";
    if (!empty($data['orders'])) {
        $order = $data['orders'][0];
        echo "<p>Latest order: #" . $order['name'] . " - $" . $order['total_price'] . "</p>";
    }
} else {
    echo "<p>❌ API Connection failed. HTTP Code: $httpCode</p>";
    echo "<p>Response: $response</p>";
}

// Test 5: File permissions and logging
echo "<h2>Test 5: File System Tests</h2>";
$testMessage = "Test log entry at " . date('Y-m-d H:i:s');
logMessage($testMessage);

if (file_exists(LOG_FILE)) {
    echo "<p>✅ Log file created/updated successfully</p>";
    $logs = file(LOG_FILE);
    echo "<p>Log file contains " . count($logs) . " entries</p>";
} else {
    echo "<p>❌ Failed to create log file</p>";
}

// Test 6: Rules file manipulation
echo "<h2>Test 6: Rules Management</h2>";
$currentRules = getTaggingRules();
echo "<p>Current rules count: " . count($currentRules) . "</p>";

// Add a test rule
$testRule = [
    'id' => 99999,
    'condition' => 'greater_than',
    'value' => 999,
    'tag' => 'TEST RULE',
    'shipping' => 'Test Shipping',
    'active' => false
];

$allRules = array_merge($currentRules, [$testRule]);
$saved = saveTaggingRules($allRules);

if ($saved) {
    echo "<p>✅ Test rule added successfully</p>";
    
    // Remove the test rule
    $filteredRules = array_filter($allRules, function($rule) {
        return $rule['id'] != 99999;
    });
    saveTaggingRules(array_values($filteredRules));
    echo "<p>✅ Test rule removed successfully</p>";
} else {
    echo "<p>❌ Failed to save test rule</p>";
}

echo "<h2>Test Summary</h2>";
echo "<p>All tests completed. Check the results above for any issues.</p>";
echo "<p><a href='index.php'>Go to Admin Interface</a></p>";
?>