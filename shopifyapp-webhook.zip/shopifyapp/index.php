<?php
require_once 'config.php';
require_once 'functions.php';

// Handle form submissions
if ($_POST) {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_rule':
                $rules = getTaggingRules();
                $newRule = [
                    'id' => time(), // Simple ID generation
                    'condition' => $_POST['condition'],
                    'value' => floatval($_POST['value']),
                    'tag' => $_POST['tag'],
                    'shipping' => $_POST['shipping'],
                    'active' => true
                ];
                $rules[] = $newRule;
                saveTaggingRules($rules);
                $message = "Rule added successfully!";
                break;
                
            case 'delete_rule':
                $rules = getTaggingRules();
                $ruleId = intval($_POST['rule_id']);
                $rules = array_filter($rules, function($rule) use ($ruleId) {
                    return $rule['id'] != $ruleId;
                });
                saveTaggingRules(array_values($rules));
                $message = "Rule deleted successfully!";
                break;
                
            case 'toggle_rule':
                $rules = getTaggingRules();
                $ruleId = intval($_POST['rule_id']);
                foreach ($rules as &$rule) {
                    if ($rule['id'] == $ruleId) {
                        $rule['active'] = !$rule['active'];
                        break;
                    }
                }
                saveTaggingRules($rules);
                $message = "Rule status updated!";
                break;
        }
    }
}

$rules = getTaggingRules();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopify Order Tagging App</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: #00848e;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        button {
            background: #00848e;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
        }
        
        button:hover {
            background: #006b75;
        }
        
        button.danger {
            background: #dc3545;
        }
        
        button.danger:hover {
            background: #c82333;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .table th, .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        
        .status-active {
            color: #28a745;
            font-weight: 500;
        }
        
        .status-inactive {
            color: #dc3545;
            font-weight: 500;
        }
        
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr 1fr;
            gap: 15px;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Shopify Order Tagging App</h1>
            <p>Automatically tag orders based on custom rules</p>
        </div>
        
        <?php if (isset($message)): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <!-- Add New Rule Form -->
        <div class="card">
            <h2>Add New Tagging Rule</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add_rule">
                <div class="form-row">
                    <div class="form-group">
                        <label for="condition">Condition</label>
                        <select name="condition" id="condition" required>
                            <option value="greater_than">Greater than</option>
                            <option value="greater_than_equal">Greater than or equal</option>
                            <option value="less_than">Less than</option>
                            <option value="less_than_equal">Less than or equal</option>
                            <option value="equal">Equal to</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="value">Order Value ($)</label>
                        <input type="number" name="value" id="value" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="tag">Tag (optional)</label>
                        <input type="text" name="tag" id="tag" placeholder="e.g., High Value">
                    </div>
                    <div class="form-group">
                        <label for="shipping">Shipping Method</label>
                        <select name="shipping" id="shipping" required>
                            <option value="Normal">Normal</option>
                            <option value="Express">Express</option>
                            <option value="Super Express">Super Express</option>
                            <option value="Same Day">Same Day</option>
                        </select>
                    </div>
                </div>
                <button type="submit">Add Rule</button>
            </form>
        </div>
        
        <!-- Current Rules -->
        <div class="card">
            <h2>Current Tagging Rules</h2>
            <?php if (empty($rules)): ?>
                <p>No rules configured yet.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Condition</th>
                            <th>Value</th>
                            <th>Tag</th>
                            <th>Shipping</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rules as $rule): ?>
                            <tr>
                                <td><?php echo ucfirst(str_replace('_', ' ', $rule['condition'])); ?></td>
                                <td>$<?php echo number_format($rule['value'], 2); ?></td>
                                <td><?php echo htmlspecialchars($rule['tag'] ?: 'No tag'); ?></td>
                                <td><?php echo htmlspecialchars($rule['shipping']); ?></td>
                                <td class="<?php echo $rule['active'] ? 'status-active' : 'status-inactive'; ?>">
                                    <?php echo $rule['active'] ? 'Active' : 'Inactive'; ?>
                                </td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="toggle_rule">
                                        <input type="hidden" name="rule_id" value="<?php echo $rule['id']; ?>">
                                        <button type="submit">
                                            <?php echo $rule['active'] ? 'Disable' : 'Enable'; ?>
                                        </button>
                                    </form>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_rule">
                                        <input type="hidden" name="rule_id" value="<?php echo $rule['id']; ?>">
                                        <button type="submit" class="danger" onclick="return confirm('Are you sure you want to delete this rule?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <!-- Webhook Information -->
        <div class="card">
            <h2>Webhook Setup</h2>
            <p><strong>Webhook URL:</strong> <?php echo 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/webhook/order-tagging.php'; ?></p>
            <p><strong>Event:</strong> Order creation</p>
            <p><strong>Format:</strong> JSON</p>
            <p>Configure this webhook in your Shopify admin under Settings → Notifications → Webhooks</p>
        </div>
        
        <!-- Recent Logs -->
        <div class="card">
            <h2>Recent Activity</h2>
            <?php
            if (file_exists(LOG_FILE)) {
                $logs = file(LOG_FILE);
                $recentLogs = array_slice(array_reverse($logs), 0, 10);
                if (!empty($recentLogs)) {
                    echo '<div style="background: #f8f9fa; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 12px;">';
                    foreach ($recentLogs as $log) {
                        echo htmlspecialchars($log) . '<br>';
                    }
                    echo '</div>';
                } else {
                    echo '<p>No recent activity.</p>';
                }
            } else {
                echo '<p>No logs available yet.</p>';
            }
            ?>
        </div>
    </div>
</body>
</html>