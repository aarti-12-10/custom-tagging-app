<?php
// Allow from any origin
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type");

// Continue with your existing code
if (isset($_GET['customer_id']) && !empty($_GET['customer_id']) || isset($_GET['shop']) && !empty($_GET['shop']) || isset($_GET['product_title']) && !empty($_GET['product_title'])) {
    include __DIR__ . '/../include/db.php';
    header('Content-Type: application/json');

    $customer_id = isset($_GET['customer_id']) ? $conn->real_escape_string($_GET['customer_id']) : '';
    $customer = $_GET['customer_id'];
    $shop_url = isset($_GET['shop']) ? $conn->real_escape_string($_GET['shop']) : '';
    $product_title = isset($_GET['product_title']) ? $conn->real_escape_string($_GET['product_title']) : '';
    if (strpos($customer, ',') !== false) {
        list($customer_id, $guest_id) = array_map('trim', explode(',', $customer));

        // Proceed if guest_id is not empty
        if (!empty($guest_id)) {
            // Check if guest_id exists in the wishlist_user table
            $check_guest_query = "SELECT customer_id FROM wishlist_user WHERE customer_id = ?";
            if ($guest_stmt = $conn->prepare($check_guest_query)) {
                $guest_stmt->bind_param("s", $guest_id);
                $guest_stmt->execute();
                $guest_stmt->store_result();

                // If guest_id exists, update it to customer_id
                if ($guest_stmt->num_rows > 0) {
                    $update_guest_query = "UPDATE wishlist_user SET customer_id = ? WHERE customer_id = ?";
                    if ($update_stmt = $conn->prepare($update_guest_query)) {
                        $update_stmt->bind_param("ss", $customer_id, $guest_id);
                        if ($update_stmt->execute()) {
                        } else {
                        }
                        $update_stmt->close();
                    }
                } else {
                }
                $guest_stmt->close();
            }
        }
    } else {
        // If only customer_id is present
        $customer_id = $customer;
    }
    // Validate the shop_url if provided
    if (!empty($shop_url)) {
        $query = "SELECT * FROM `shop` WHERE shop_url='$shop_url' LIMIT 1";
        $shop_result = $conn->query($query);

        if ($shop_result && $shop_result->num_rows == 0) {
            echo json_encode(['error' => 'Invalid shop URL']);
            $conn->close();
            exit;
        }
    }

    // Build the WHERE clause dynamically
    $whereClauses = [];

    if (!empty($customer_id)) {
        $whereClauses[] = "customer_id = '$customer_id'";
    }

    if (!empty($shop_url)) {
        $whereClauses[] = "shop_url = '$shop_url'";
    }

    if (!empty($product_title)) {
        $whereClauses[] = "product_title = '$product_title'";
    }

    if (!empty($whereClauses)) {
        $whereClause = "WHERE " . implode(' AND ', $whereClauses);
        $sql = "SELECT * FROM wishlist_user $whereClause";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $wishlist_data = [];
            while ($row = $result->fetch_assoc()) {
                $wishlist_data[] = $row;
            }
            echo json_encode($wishlist_data, JSON_PRETTY_PRINT);
        } else {
            echo json_encode(['error' => 'No records found']);
        }
    } else {
        echo json_encode(['error' => 'No valid parameters provided']);
    }

    $conn->close();
} else {
    echo json_encode(['error' => 'Invalid request parameters']);
}
?>
