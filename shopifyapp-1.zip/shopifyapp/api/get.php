<?php
// Allow from any origin (for development purposes; restrict in production)
header("Access-Control-Allow-Origin: *");

// Allow specific methods
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

// Allow specific headers
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Set content type to JSON
header('Content-Type: application/json');

// Include database connection file
include __DIR__ . '/../include/db.php';

// Handle preflight request (OPTIONS request)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Get the shop URL from the query string
$shop_url = $_GET['shop'] ?? '';

if (empty($shop_url)) {
    echo json_encode(["error" => "Shop URL parameter is missing"]);
    exit;
}

// Prepare the SQL query
$query = "SELECT * FROM `theme` WHERE shop_url = '" . $conn->real_escape_string($shop_url) . "'";

// Execute the query
$result = $conn->query($query);

// Check if the query was successful
if ($result) {
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    // Log the SQL error
    error_log("Database query failed: " . $conn->error);
    echo json_encode(["error" => "Database query failed"]);
}

// Close the database connection
$conn->close();
?>
