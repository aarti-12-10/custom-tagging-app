<?php

// CORS Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Preflight request handling for CORS (OPTIONS request)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header('HTTP/1.1 200 OK');
    exit;
}

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "S-XRWpshU-KqWfeO";
$dbname = "wishlist";

try {
    // Create connection using PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get the raw POST data
    $input = file_get_contents('php://input');
    $data = json_decode($input, true); // Decode the JSON data into a PHP associative array

    // Check if shop_url, product_title, and customer_id are set in the decoded JSON data
    if (isset($data['shop_url']) && isset($data['product_title']) && isset($data['customer_id'])) {
        $shop_url = $data['shop_url'];
        $product_title = $data['product_title'];
        $customer = $data['customer_id'];
        
        $product_img = $data['product_img'];

        // Validate shop URL against your database
        $stmt = $conn->prepare("SELECT COUNT(*) FROM shop WHERE shop_url = :shop_url LIMIT 1");
        $stmt->bindParam(':shop_url', $shop_url);
        $stmt->execute();

        if (strpos($customer, ',') !== false) {
            list($customer_id, $guest_id) = array_map('trim', explode(',', $customer));
            if ($guest_id) {
                // Check if the guest ID exists in the wishlist_user table
                $guest_stmt = $conn->prepare("SELECT customer_id FROM wishlist_user WHERE customer_id = :guest_id");
                $guest_stmt->bindValue(':guest_id', $guest_id, PDO::PARAM_STR);
                $guest_stmt->execute();

                // If guest ID exists, update it with the real customer ID
                if ($guest_stmt->rowCount() > 0) {
                    // Update the record where the guest ID exists
                    $update_stmt = $conn->prepare("UPDATE wishlist_user SET customer_id = :customer_id WHERE customer_id = :guest_id");
                    $update_stmt->bindValue(':customer_id', $customer_id, PDO::PARAM_STR);
                    $update_stmt->bindValue(':guest_id', $guest_id, PDO::PARAM_STR);
                    if ($update_stmt->execute()) {
                    } else {
                    }
                }
            }
        }else{
            $customer_id = $customer;
        }
        
        if ($stmt->fetchColumn() > 0) {
            // Shop URL is valid, proceed to delete the record matching shop_url, product_title, and customer_id
            $deleteStmt = $conn->prepare("DELETE FROM wishlist_user WHERE shop_url = :shop_url AND product_title = :product_title AND customer_id = :customer_id");
            $deleteStmt->bindParam(':shop_url', $shop_url);
            $deleteStmt->bindParam(':product_title', $product_title);
            $deleteStmt->bindParam(':customer_id', $customer_id);
            $deleteStmt->execute();

            if ($deleteStmt->rowCount() > 0) {
               echo json_encode(["message" => "Record Deleted successfully","title"=>$product_title, "product_img"=>$product_img]);

            } else {
                echo "No matching record found to delete";
            }
        } else {
            echo "Invalid shop URL";
        }
    } else {
        // Debugging: Show which parameters are missing
        echo "Missing Parameters: ";
        if (!isset($data['shop_url'])) echo "shop_url ";
        if (!isset($data['product_title'])) echo "product_title ";
        if (!isset($data['customer_id'])) echo "customer_id ";
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
