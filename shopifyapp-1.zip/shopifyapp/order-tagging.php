<?php
// Shopify Admin API access
$shop = "aarti1210.myshopify.com";
$access_token = "shpua_1860af592f6346e7b99577f76f7d472a"; // from app setup         

// Get order webhook payload
$data = file_get_contents("php://input");
$order = json_decode($data, true);

$order_id = $order['id'];

// 👇 Custom condition
if ($order['total_price'] > 500) {
    $tags = "High Value";

    $url = "https://$shop/admin/api/2024-10/orders/$order_id.json";

    $payload = json_encode([
        "order" => [
            "id" => $order_id,
            "tags" => $tags
        ]
    ]);

    $headers = [
        "Content-Type: application/json",
        "X-Shopify-Access-Token: $access_token"
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    file_put_contents("log.txt", "Status Code: $http_code\nResponse: $response", FILE_APPEND);
}
?>
