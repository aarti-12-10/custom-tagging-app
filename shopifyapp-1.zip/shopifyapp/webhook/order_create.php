<?php
// 1. Get the incoming order data from webhook
$rawData = file_get_contents('php://input');
$order = json_decode($rawData, true) ;

// 2. Load shop domain and access token
$shop = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN']; // e.g., quickstart-91c225da.myshopify.com
$access_token = 'shpua_1860af592f6346e7b99577f76f7d472a'; // Replace or load from DB based on $shop

$order_id = $order['id'] ?? null;
$total_price = floatval($order['total_price'] ?? 0);

// 3. Determine tag and shipping method
$tag = "";
$shipping_title = "Standard";

if ($total_price > 500) {
    $tag = "Very High Value";
    $shipping_title = "Super Express";
} elseif ($total_price > 100) {
    $tag = "High Value";
    $shipping_title = "Express";
} elseif ($total_price <= 100) {
    $tag = "";
    $shipping_title = "Normal";
}

// 4. Update order tags and shipping title
if ($order_id) {
    // Add tag
    $update_data = [
        "order" => [
            "id" => $order_id,
            "tags" => $tag
        ]
    ];

    $ch = curl_init("https://$shop/admin/api/2024-01/orders/$order_id.json");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($update_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "X-Shopify-Access-Token: $access_token"
    ]);
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Log result
    file_put_contents('log.txt', "Tagged order $order_id with '$tag'. Status: $status\n", FILE_APPEND);

    // ⚠️ Shipping method is usually set at checkout and **cannot** be changed later via API.
    // But you can store it as metafield or just use the tag to notify staff.
}
