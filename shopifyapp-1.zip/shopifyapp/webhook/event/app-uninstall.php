<?php
include "include/shopify-data.php";
// Define your Shopify shared secret
$shared_secret = $_API_SECRET;

$servername = "localhost";
$username = "root";
$password = "";
$database = "shopifyapp";

$conn = new mysqli($servername, $username, $password, $database);
$file = fopen('debugs.txt', 'w');
if ($conn->connect_error) {
    fwrite($file, "Connection Fail \n");
}
define('SHOPIFY_CLIENT_SECRET', '484f7db11934101c31233aed1c743556');

function verify_webhook($data, $hmac_header) {
    $calculated_hmac = base64_encode(hash_hmac('sha256', $data, SHOPIFY_CLIENT_SECRET, true));
    return hash_equals($calculated_hmac, $hmac_header);
}

$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
$data = file_get_contents('php://input');
$array_data = json_decode($data, true);
$verified = verify_webhook($data, $hmac_header);

error_log('Webhook verified: ' . var_export($verified, true));

$DeleteQuery = "DELETE FROM `shop` WHERE shop_url='" . $array_data['myshopify_domain'] . "'";
fwrite($file, $DeleteQuery);
$result = $conn->query($DeleteQuery);
fwrite($file, $result);
