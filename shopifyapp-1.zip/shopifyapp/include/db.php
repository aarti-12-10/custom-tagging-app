<?php

// create table in database 
// - shop table name
// -   id int Auto Increment  
// -   shop_url varchar(255)  
// -   access_token varchar(255)  
// -   hmac varchar(255)  
// -   install_date datetime


$servername = "localhost";
$username = "root";
$password = "";
$database = "shopifyapp";
// Create connection
$conn = new mysqli($servername, $username, $password, $database);


// Check connection


if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else {
  echo "Connection successfully";
}
?>
