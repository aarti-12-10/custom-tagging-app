<?php
$_API_KEY = 'af038cce925bdf6dd066b01574360857'; // api key 
$_API_SECRET = 'e65f47391756a7054e3dcca9aaed8b7f'; // api scret key 
$_NGROK_URL = 'https://e6d92045861d.ngrok-free.app/shopifyapp';  // main folder url with ngrok 
$_SHOPIFY_ADMIN_APP = 'custom-order-tagging-app';  // shopify admin in app url  
