<?php
try {
    include "include/shopify-data.php";
    include "include/db.php";

    if (!isset($_GET['hmac'], $_GET['shop'], $_GET['code'])) {
        throw new Exception('Missing parameters');
    }

    $params = $_GET;
    $hmac = $params['hmac'];
    $shop_url = $params['shop'];

    // Remove hmac then sort and hash
    $params = array_diff_key($params, ['hmac' => '']);
    ksort($params);
    $computed_hmac = hash_hmac('sha256', http_build_query($params), $_API_SECRET);

    if (!hash_equals($hmac, $computed_hmac)) {
        throw new Exception('This request is NOT from Shopify!');
    }

    // Exchange code for access_token
    $query = [
        "client_id" => $_API_KEY,
        "client_secret" => $_API_SECRET,
        "code" => $_GET['code']
    ];

    $access_token_url = "https://$shop_url/admin/oauth/access_token";
    $ch = curl_init($access_token_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($query));
    $response = curl_exec($ch);
    if ($response === false) throw new Exception("Curl error: " . curl_error($ch));
    curl_close($ch);

    $result = json_decode($response, true);
    if (!isset($result['access_token'])) throw new Exception("Access token not found in response");

    $access_token = $result['access_token'];
    $time = date("Y-m-d H:i:s");

    // Save to DB
    $shop_sql = "SELECT * FROM `shop` WHERE shop_url='" . $conn->real_escape_string($shop_url) . "' LIMIT 1";
    $shop_result = $conn->query($shop_sql);

    if ($shop_result->num_rows < 1) {
        $status = 1;
        $insert_sql = "INSERT INTO `shop`(`shop_url`, `access_token`, `hmac`, `install_date`, `status`)
            VALUES ('$shop_url', '$access_token', '$hmac', '$time', '$status')
            ON DUPLICATE KEY UPDATE access_token='$access_token', hmac='$hmac'";
        if (!$conn->query($insert_sql)) throw new Exception("DB Insert error: " . $conn->error);
    } else {
        $update_sql = "UPDATE `shop` SET `status`='1', `access_token`='$access_token', `hmac`='$hmac', `install_date`='$time' WHERE shop_url='$shop_url'";
        if (!$conn->query($update_sql)) throw new Exception("DB Update error: " . $conn->error);
    }

    // ✅ Register Webhook for order creation
    $webhook_url = "https://efb6f02ddbfe.ngrok-free.app/webhook/order_created.php"; // replace with actual HTTPS URL
    $webhook_payload = [
        "webhook" => [
            "topic" => "orders/create",
            "address" => $webhook_url,
            "format" => "json"
        ]
    ];
    $webhook_headers = [
        "X-Shopify-Access-Token: $access_token",
        "Content-Type: application/json"
    ];

    $ch = curl_init("https://$shop_url/admin/api/2024-01/webhooks.json");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($webhook_payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $webhook_headers);
    $webhook_response = curl_exec($ch);
    curl_close($ch);

    // ✅ Redirect to app page inside Shopify
    header("Location: https://$shop_url/admin/apps/$_SHOPIFY_ADMIN_APP");
    exit();

} catch (Exception $e) {
    error_log("Token Exchange Error: " . $e->getMessage());
    die("Error: " . htmlspecialchars($e->getMessage()));
}
