<?php 

include "include/shopify-data.php";

$Shop = $_GET['shop'];

$Scope = 'write_products,read_customers,read_themes,write_themes,read_customers,customer_read_customers';
$redirect_url = $_NGROK_URL.'/token.php';


$oauth_url = 'https://'.$Shop.'/admin/oauth/authorize?client_id='.$_API_KEY.'&scope='.$Scope.'&redirect_uri='.urlencode($redirect_url);

header("Location: ". $oauth_url);
exit();

?>
