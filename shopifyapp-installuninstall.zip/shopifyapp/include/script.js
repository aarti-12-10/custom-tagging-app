// save btn enable disable on data change

document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".main-form");
  const saveBtn = document.getElementById("saveBtn");
  const menuLinks = document.querySelectorAll('.side-nav a');

  // Get initial form state
  let initialFormData = new FormData(form);

  // Function to compare form data
  const isFormChanged = () => {
    let currentFormData = new FormData(form);

    for (let [key, value] of initialFormData.entries()) {
      if (value !== currentFormData.get(key)) {
        return true; // form data has changed
      }
    }
    return false; // no changes detected
  };

  // Event listener for form inputs
  form.addEventListener("input", () => {
    if (isFormChanged()) {
      saveBtn.disabled = false; // Enable button if any changes are made
    } else {
      saveBtn.disabled = true; // Disable button if no changes
    }
  });

  // Function to check if navigation should be allowed
  const shouldAllowNavigation = (event) => {
    if (!saveBtn.disabled) {
      // Save button is enabled, meaning there are unsaved changes
      event.preventDefault(); // Prevent the default link navigation
      alert("Please save changes before you go to another tab."); // Show notification
    }
  };

  // Add event listener to all navigation links
  menuLinks.forEach((link) => {
    link.addEventListener("click", shouldAllowNavigation);
  });

  function defaultColorPicker() {
    const colorPickers = document.querySelectorAll(".color-picker");
    colorPickers.forEach((picker) => {
      const colorCode = picker
        .closest(".color-picker-wrapper")
        .querySelector(".colorCode");
      colorCode.textContent = picker.value;
    });
  }
  window.onload = defaultColorPicker;
});
