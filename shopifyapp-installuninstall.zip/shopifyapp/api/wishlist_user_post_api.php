<?php

// CORS Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight (OPTIONS) requests for CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header('HTTP/1.1 200 OK');
    exit;
}

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
include __DIR__ . '/../include/db.php';

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get raw POST data and decode JSON
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Log received data for debugging
    error_log("Received data: " . var_export($data, true));

    // Handle invalid JSON data
    if ($data === null) {
        error_log("Failed to decode JSON: " . json_last_error_msg());
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(["error" => "Invalid JSON data"]);
        exit;
    }

    // Extract fields from decoded JSON
    $shop_url = trim($data['shop_url'] ?? '');
    $customer = $data['customer_id'] ?? '';
    $product_img = $data['product_img'] ?? '';
    $product_title = $data['product_title'] ?? '';
    $product_price = $data['product_price'] ?? '';
    $product_url = $data['product_url'] ?? '';
    $myfile = fopen("testfile.txt", "w");
    // Validate shop_url
    $shop_query = "SELECT * FROM `shop` WHERE shop_url = ? LIMIT 1";
    error_log("Shop URL Query: $shop_query"); // Log query for debugging

    if ($shop_stmt = $conn->prepare($shop_query)) {
        $shop_stmt->bind_param("s", $shop_url);
        $shop_stmt->execute();
        $shop_result = $shop_stmt->get_result();

        // Check customer and guest ID handling
        if (strpos($customer, ',') !== false) {
            list($customer_id, $guest_id) = array_map('trim', explode(',', $customer));
            if (!empty($guest_id)) {
                $check_guest_query = "SELECT customer_id FROM wishlist_user WHERE customer_id = ?";
                if ($guest_stmt = $conn->prepare($check_guest_query)) {
                    $guest_stmt->bind_param("s", $guest_id);
                    $guest_stmt->execute();
                    $guest_stmt->store_result();

                    // Update guest ID to customer ID if guest ID exists
                    if ($guest_stmt->num_rows > 0) {
                        $update_guest_query = "UPDATE wishlist_user SET customer_id = ? WHERE customer_id = ?";
                        if ($update_stmt = $conn->prepare($update_guest_query)) {
                            $update_stmt->bind_param("ss", $customer_id, $guest_id);
                            if ($update_stmt->execute()) {
                            } else {
                               $customer_id = $customer_id;
                            }
                            $update_stmt->close();
                        }
                    }
                    $guest_stmt->close();
                }
            }
        }else{
            $customer_id = $customer;
        }
        
        // Insert into wishlist_user if shop_url is valid
        if ($shop_result && $shop_result->num_rows > 0) {
            $insert_query = "INSERT INTO wishlist_user (shop_url, customer_id, product_img, product_title, product_price, product_url) 
                             VALUES (?, ?, ?, ?, ?, ?)";

            if ($insert_stmt = $conn->prepare($insert_query)) {
                $insert_stmt->bind_param("ssssss", $shop_url, $customer_id, $product_img, $product_title, $product_price, $product_url);

                if ($insert_stmt->execute()) {
                    echo json_encode([
                        "message" => "Record created successfully",
                        "title" => $product_title,
                        "product_img" => $product_img
                    ]);
                } else {
                    error_log("Database insert error: " . $insert_stmt->error);
                    header('HTTP/1.1 500 Internal Server Error');
                    echo json_encode(["error" => "Database insert error: " . $insert_stmt->error]);
                }
                $insert_stmt->close();
            } else {
                error_log("SQL preparation error: " . $conn->error);
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode(["error" => "SQL preparation error"]);
            }
        } else {
            error_log("Invalid shop URL: $shop_url");
            header('HTTP/1.1 403 Forbidden');
            echo json_encode(["error" => "Invalid shop URL"]);
        }

        $shop_stmt->close();
    } else {
        error_log("SQL preparation error for shop query: " . $conn->error);
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(["error" => "Failed to prepare shop query"]);
    }

    $conn->close();
} else {
    // Handle invalid request methods
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(["error" => "Invalid request method"]);
}

?>
