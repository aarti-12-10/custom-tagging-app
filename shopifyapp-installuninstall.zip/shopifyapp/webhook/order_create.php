<?php
// webhook/order_create.php

// Verify webhook authenticity
$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
$input = file_get_contents('php://input');
$calculated_hmac = base64_encode(hash_hmac('sha256', $input, 'e65f47391756a7054e3dcca9aaed8b7f', true));

if (!hash_equals($hmac_header, $calculated_hmac)) {
    http_response_code(403);
    exit("Unauthorized");
}

// Parse order data
$order = json_decode($input, true);
$order_id = $order['id'];
$total_price = floatval($order['total_price']);
$shop = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];

// Load access token from DB
require_once('../include/db.php'); // Adjust path as needed
$access_token = getAccessToken($shop); // You must define this function

// Define tags
$tag = "";
$shipping = "Normal";

if ($total_price > 500) {
    $tag = "Very High Value";
    $shipping = "Super Express";
} elseif ($total_price > 100) {
    $tag = "High Value";
    $shipping = "Express";
}

// Call Shopify Admin API to update the order
$update_data = [
    "order" => [
        "id" => $order_id,
        "tags" => $tag
    ]
];

$ch = curl_init("https://$shop/admin/api/2024-04/orders/$order_id.json");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($update_data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "X-Shopify-Access-Token: $access_token"
]);
$response = curl_exec($ch);
curl_close($ch);

// Optional logging
file_put_contents("../logs/order_log.txt", $response . PHP_EOL, FILE_APPEND);
