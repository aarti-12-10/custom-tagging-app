<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.1.1.min.js"> </script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<?php
// if you want  to install this app than remove comment  first and access_token change
// header("Location: install.php?shop=" . $_GET['shop']);
// exit();
include "include/db.php";
include "include/shopify.php";
include "include/shopify-data.php";
session_start();

$query = "SELECT * FROM `shop` WHERE shop_url='" . $_GET['shop'] . "' LIMIT 1";
// var_dump($query); die();
$result = $conn->query($query);

if ($result->num_rows < 1) {
    header("Location: install.php?shop=" . $_GET['shop']);
    exit();
}

// die;
$stor_data = $result->fetch_assoc();
// echo "pre";      
// print_r($stor_data); die();
if ($stor_data['status'] != '1') {
    header("Location: install.php?shop=" . $_GET['shop']);
    exit();
}
$access_token = $stor_data['access_token'];
$shopify_url = $stor_data['shop_url'];

                                                                                                                                                                                                                                                                                                                                                                                                                                                   
$_SESSION['shop_url'] = $shopify_url;
// echo $_SESSION['shop_url'];
$shopify = new Shopify();
$shopify->set_url($shopify_url);
$shopify->set_token($access_token);
include "webhook/index.php";

// $UserQuery = "SELECT * FROM `User` WHERE shop_url='" . $shopify_url . "' LIMIT 1";
// var_dump(UserQuery);

// $UserResult = $conn->query($UserQuery);
// $UserData = $UserResult->fetch_assoc(); 


?>

 